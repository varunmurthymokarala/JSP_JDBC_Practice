package com.ilp.beans;

public class BloodBanks {

	private Integer id;
	private String name;
	private Integer number;
	private String gender;
	private String bloodgroup;
	private String city;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getNumber() {
		return number;
	}
	public void setNumber(Integer number) {
		this.number = number;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getBloodgroup() {
		return bloodgroup;
	}
	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "BloodBanks [id=" + id + ", name=" + name + ", number=" + number + ", gender=" + gender + ", bloodgroup="
				+ bloodgroup + ", city=" + city + "]";
	}
	
	
	

}
