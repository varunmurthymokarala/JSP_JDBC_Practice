package com.ILPday03;

//import com.day03.Child;

public class CustomerDemo {

	public static void main(String[] args) {
		
			Customer c1 = new Customer(101, "var", "2/02/2020", 2000, "abc@gmail.com", 25);
			c1.display();
			
			Child c2 = new Child(102, "varv", "23/02/2020", 5000, "abcd@gmail.com", 250, 1200, "savings", 100, 2);
			c2.display();

		

	}

}
